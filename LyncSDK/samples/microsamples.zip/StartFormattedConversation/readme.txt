Copyright (c) Microsoft Corporation.  All rights reserved.

Send formatted conversation sample

Sample location:

64Bit Operating System: %PROGRAMFILES(X86)%\Microsoft Lync\SDK\Samples\StartFormattedConversation
32Bit Operating System: %PROGRAMFILES%\Microsoft Lync\SDK\Samples\StartFormattedConversation

Features:
Send plain text, html, rtf, ink, gif formats.

Warnings:
Lync client not found- run lync client 

Prerequisites (for compiling and running in Visual Studio)
- .Net Framework 3.5 or above.
- Visual Studio 2008 or 2010
- Microsoft Lync 2013 SDK

Prerequisites (for running installed sample on client machines)
- Microsoft Lync 2013 must be installed and running.

Running the sample
------------------
1. Open StartFormattedConversation.csproj file.
2. Click F5
