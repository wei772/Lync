Introduction
=============
This application demonstrates the ability to start and accept Whiteboard and PowerPoint sharing using ContentShaingModality.


Sample location
================
64Bit Operating System: %PROGRAMFILES(X86)%\Microsoft Lync\SDK\Samples\ContentModalitySample
32Bit Operating System: %PROGRAMFILES%\Microsoft Lync\SDK\Samples\ContentModalitySample


Features
========
- Create a conversation with a remote party.
- Share whiteboard with another user.
- Share PowerPoint presentation with another user and navigates the slides.
- Show Content Bin in app UI.
- Choose and present a content from Content Bin.
- Take over as presenter. (Choose the content and click Present)
- Accept an incoming sharing session. 


Warnings
========
- Project file included in this sample is for Visual Studio 2010.
- Copy the ContentModalitySample folder to a user folder, outside of Program Files.
- Both Lync and the the sample must run with the same priviliges.
- To reduce UI related code, sample doesn't enable and disable buttons. Please follow the sequence and restart the sample
  after each conversation. 


Prerequisites (for compiling and running in Visual Studio)
===========================================================
- .Net Framework 4.0 or above.
- Visual Studio 2010
- Microsoft Lync 2013 SDK


Prerequisites (for running installed sample on client machines)
================================================================
- Microsoft Lync 2013 must be installed and running.


Running the sample
==================
1. Open "ContentModalitySample.sln".
2. Confirm Microsoft.Lync.Model reference is pointing to the location where your Microsoft.Lync.Model.dll file is.
3. Ensure no Lync Conversation Window is open then hit F5
4. Once the sample app starts up, enter sip URI of a user who you want to contact and press Create Conversation button.
5. Accept the toast on remote user's side. Ensure Lync Converation Windows are open before clicking another button.
6. To start Whiteboard, enter title and press Create Whiteboard.
7. To start PowerPoint, enter title and full file path then press Create PowerPoint.
8. Please ensure you enter unique title for each time.
9. Once the created content shows up in Content Bin, select it and click Present to show it in Lync Conversation Window.
10. To Accept an incomng call, start the sample before the remote party calls, then click Accept when call comes.
11. Message and tips will show at the bottom of the sample as you use it.
9. To Accept a call, wait for the toast to show up and then click Accept Toast button.

